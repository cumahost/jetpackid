<?php
// Plugin dummy